from __future__ import annotations
from typing import Dict, List
from .models import RoutePlan


def plan_deepseek_v4_route(task: Dict, risk_terms: List[str], context_chars: int, evidence_count: int) -> RoutePlan:
    complexity = 0
    text = str(task).lower()
    for kw in ["法律", "医疗", "金融", "策略", "代码", "审计", "政策", "科研", "方案", "治理", "安全", "招标"]:
        if kw.lower() in text:
            complexity += 1
    if context_chars > 12000:
        complexity += 2
    if evidence_count >= 4:
        complexity += 1
    if risk_terms:
        complexity += 2

    if complexity >= 5:
        model = "deepseek-v4-pro"
        thinking = "thinking"
        budget = "audit"
    elif complexity >= 3:
        model = "deepseek-v4-pro"
        thinking = "thinking_or_auto"
        budget = "normal"
    else:
        model = "deepseek-v4-flash"
        thinking = "non_thinking_or_auto"
        budget = "low"

    context_strategy = "1M-context ready: keep evidence ledger and residual queue; avoid dumping raw private data."
    risk_mode = "human_review_required" if risk_terms else "standard_review"
    tool_use = "Tool calls may be used only after CommandProposal-style intent/evidence boundary is satisfied."

    rationale = [
        f"complexity_score={complexity}",
        f"context_chars={context_chars}",
        f"evidence_count={evidence_count}",
        f"risk_terms={len(risk_terms)}",
    ]
    return RoutePlan(
        target_family="DeepSeek V4",
        recommended_model=model,
        thinking_mode=thinking,
        context_strategy=context_strategy,
        output_budget=budget,
        tool_use=tool_use,
        risk_mode=risk_mode,
        rationale=rationale,
    )
