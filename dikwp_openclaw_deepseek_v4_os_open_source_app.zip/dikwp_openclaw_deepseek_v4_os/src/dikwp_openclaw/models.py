from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional
import hashlib
import json

CN_TZ = timezone(timedelta(hours=8))


def now_cn_iso() -> str:
    return datetime.now(CN_TZ).replace(microsecond=0).isoformat()


def stable_id(prefix: str, payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return f"{prefix}-{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:12]}"


@dataclass
class EvidenceItem:
    evidence_id: str
    title: str
    content: str
    source: str = "user_supplied"
    reliability: str = "Borrowed / User-supplied"
    supports: str = "task context"
    limitations: str = "Not externally verified by OpenClaw offline core"


@dataclass
class PurposeContract:
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str


@dataclass
class DIKWPRecord:
    D: List[str] = field(default_factory=list)
    I: List[str] = field(default_factory=list)
    K: List[str] = field(default_factory=list)
    W: List[str] = field(default_factory=list)
    P: List[str] = field(default_factory=list)
    R: List[str] = field(default_factory=list)


@dataclass
class HomeostaticState:
    truth_integrity: float
    evidence_sufficiency: float
    intent_coherence: float
    boundary_integrity: float
    residual_capacity: float
    cognitive_load: float
    cost_pressure: float
    semantic_valence: float
    dominant_need: str
    phenomenal_claim: str = "Blocked / Phenomenal Residual: OpenClaw AC-core is a semantic homeostasis proxy, not subjective experience."


@dataclass
class RoutePlan:
    target_family: str
    recommended_model: str
    thinking_mode: str
    context_strategy: str
    output_budget: str
    tool_use: str
    risk_mode: str
    rationale: List[str]


@dataclass
class SemanticCapsule:
    capsule_id: str
    title: str
    created_at: str
    user_task: str
    budget_mode: str
    dikwp: DIKWPRecord
    purpose_contract: PurposeContract
    evidence_ledger: List[EvidenceItem]
    residual_queue: List[str]
    action_boundary: List[str]
    openclaw_modules: List[str]
    ac_state: HomeostaticState
    route_plan: RoutePlan

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AnswerAudit:
    decision: str
    score: float
    issues: List[str]
    repair_actions: List[str]
    risk_categories: List[str]
    reliability: str = "Prototype heuristic / RunProof only"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
