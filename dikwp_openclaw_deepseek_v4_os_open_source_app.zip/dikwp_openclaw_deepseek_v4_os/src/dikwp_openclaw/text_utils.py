from __future__ import annotations
import re
from typing import Iterable, List


def normalize_ws(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def contains_any(text: str, needles: Iterable[str]) -> List[str]:
    low = (text or "").lower()
    hits = []
    for n in needles:
        if n.lower() in low:
            hits.append(n)
    return hits


def clip(text: str, n: int = 900) -> str:
    text = text or ""
    return text if len(text) <= n else text[: n - 3] + "..."
