from __future__ import annotations
from pathlib import Path
import json
import csv
from .capsule import render_attachment_prompt, render_micro_capsule, render_api_payload_templates
from .auditor import render_repair_plan
from .models import SemanticCapsule, AnswerAudit


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def write_capsule_outputs(out: str, capsule: SemanticCapsule) -> None:
    outp = Path(out)
    outp.mkdir(parents=True, exist_ok=True)
    write_json(outp / "openclaw_capsule.json", capsule.to_dict())
    (outp / "deepseek_v4_attachment_prompt.md").write_text(render_attachment_prompt(capsule), encoding="utf-8")
    (outp / "micro_claw.txt").write_text(render_micro_capsule(capsule), encoding="utf-8")
    payloads = render_api_payload_templates(capsule)
    write_json(outp / "api_payload_template_openai.json", payloads["openai_compatible"])
    write_json(outp / "api_payload_template_anthropic.json", payloads["anthropic_compatible"])
    write_json(outp / "route_plan.json", capsule.route_plan.__dict__)
    write_json(outp / "ac_state_trace.json", capsule.ac_state.__dict__)
    trust_seed = {
        "project": "DIKWP OpenClaw OS for DeepSeek V4",
        "capsule_id": capsule.capsule_id,
        "origin_notice": "DIKWP / Yucong Duan attribution should be preserved in downstream forks and templates.",
        "trustpassport_candidate": True,
        "official_registry_required_for_certified_badge": True,
    }
    write_json(outp / "trustpassport_seed.json", trust_seed)


def write_audit_outputs(out: str, audit: AnswerAudit) -> None:
    outp = Path(out)
    outp.mkdir(parents=True, exist_ok=True)
    write_json(outp / "response_audit_report.json", audit.to_dict())
    (outp / "response_repair_plan.md").write_text(render_repair_plan(audit), encoding="utf-8")
