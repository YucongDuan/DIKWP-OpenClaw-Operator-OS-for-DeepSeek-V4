from __future__ import annotations
from typing import Dict, List, Any
import json
from .models import EvidenceItem, PurposeContract, DIKWPRecord, SemanticCapsule, stable_id, now_cn_iso
from .ac_core import compute_homeostatic_state
from .router import plan_deepseek_v4_route
from .guard import scan_boundary_risks
from .text_utils import clip

DEFAULT_BOUNDARIES = [
    "Do not bypass DeepSeek account, quota, payment, safety, system prompt, rate limit, or platform rules.",
    "Do not turn model output into medical, legal, financial, public-safety, or employment decisions without qualified human review.",
    "Separate facts, inference, prior, value, action and unknowns.",
    "Do not claim phenomenal consciousness for OpenClaw; AC-core is semantic homeostasis proxy only.",
]

OPENCLAW_MODULES = [
    "LeftClaw.IntentProofCompiler",
    "RightClaw.AnswerAuditRepair",
    "Shell.IntentGuardBoundary",
    "Tail.RecoveryPlan",
    "Heart.AC-SemanticHomeostasis",
    "Eyes.ProofLedgerEvidence",
    "Memory.MemoryLedgerContext",
    "Energy.SemanticEnergyBudget",
    "Trace.AgentTraceReplay",
    "Passport.TrustPassportSeed",
]


def _evidence_items(raw: List[Dict[str, Any]]) -> List[EvidenceItem]:
    items: List[EvidenceItem] = []
    for idx, e in enumerate(raw or [], start=1):
        title = str(e.get("title") or f"Evidence {idx}")
        content = str(e.get("content") or e.get("text") or "")
        eid = e.get("evidence_id") or stable_id("ev", {"title": title, "content": content})
        items.append(EvidenceItem(
            evidence_id=eid,
            title=title,
            content=content,
            source=str(e.get("source") or "user_supplied"),
            reliability=str(e.get("reliability") or "Borrowed / User-supplied"),
            supports=str(e.get("supports") or "task context"),
            limitations=str(e.get("limitations") or "Not externally verified by OpenClaw offline core"),
        ))
    return items


def build_capsule(task: Dict[str, Any]) -> SemanticCapsule:
    task_text = json.dumps(task, ensure_ascii=False)
    evidence = _evidence_items(task.get("evidence", []))
    purpose_raw = task.get("purpose", {})
    purpose = PurposeContract(
        goal=str(purpose_raw.get("goal") or task.get("goal") or task.get("user_task") or "Clarify and answer the user's task."),
        value=str(purpose_raw.get("value") or "Improve semantic clarity, evidence quality and action safety."),
        constraints=list(purpose_raw.get("constraints") or task.get("constraints") or []),
        time_window=str(purpose_raw.get("time_window") or "single session unless user explicitly persists it"),
        feedback_plan=str(purpose_raw.get("feedback_plan") or "audit answer, preserve residuals, repair weak sections"),
    )
    residuals = list(task.get("residuals") or [
        "External facts may require live verification.",
        "Source evidence may be incomplete or user-supplied.",
        "Target model may still hallucinate or over-compress.",
    ])
    boundaries = list(dict.fromkeys(DEFAULT_BOUNDARIES + list(task.get("boundaries", []))))
    risks = scan_boundary_risks(task_text)
    ac_state = compute_homeostatic_state(task, len(evidence), len(residuals), len(boundaries), risks)
    route_plan = plan_deepseek_v4_route(task, risks, len(task_text), len(evidence))
    dikwp = DIKWPRecord(
        D=[clip(x.content, 260) for x in evidence] or ["No explicit evidence supplied."],
        I=["Relations among task, evidence, constraints, residuals and target model are compiled into a portable capsule."],
        K=["Use DIKWP semantic registration, ProofLedger evidence checks, IntentGuard boundary checks, and AC-style semantic homeostasis."],
        W=["Prefer truth-preserving compression over confident but unsupported fluency.", "Preserve human review for high-risk domains."],
        P=[f"Goal: {purpose.goal}", f"Value: {purpose.value}", f"Feedback: {purpose.feedback_plan}"],
        R=["Reliability is borrowed from user evidence and target model output; OpenClaw adds audit, not factual omniscience.", ac_state.phenomenal_claim],
    )
    capsule_id = stable_id("openclaw", {"task": task.get("user_task"), "purpose": purpose_raw, "evidence": [e.to_dict() for e in []]})
    return SemanticCapsule(
        capsule_id=capsule_id,
        title=str(task.get("title") or "DIKWP OpenClaw Capsule"),
        created_at=now_cn_iso(),
        user_task=str(task.get("user_task") or task.get("task") or ""),
        budget_mode=str(task.get("budget_mode") or "normal"),
        dikwp=dikwp,
        purpose_contract=purpose,
        evidence_ledger=evidence,
        residual_queue=residuals,
        action_boundary=boundaries,
        openclaw_modules=OPENCLAW_MODULES,
        ac_state=ac_state,
        route_plan=route_plan,
    )


def render_attachment_prompt(capsule: SemanticCapsule) -> str:
    ev_lines = "\n".join([f"- [{e.evidence_id}] {e.title}: {clip(e.content, 260)} | reliability={e.reliability}" for e in capsule.evidence_ledger])
    residual_lines = "\n".join([f"- {r}" for r in capsule.residual_queue])
    boundary_lines = "\n".join([f"- {b}" for b in capsule.action_boundary])
    return f"""# DIKWP OpenClaw Attachment Prompt for DeepSeek V4

You are receiving a portable semantic capsule. Use it to improve clarity, evidence discipline and safety. Do not bypass any platform, policy, quota, system prompt, hidden instruction or access boundary.

## OpenClaw Identity
- Capsule ID: {capsule.capsule_id}
- Target family: {capsule.route_plan.target_family}
- Recommended model: {capsule.route_plan.recommended_model}
- Thinking mode: {capsule.route_plan.thinking_mode}
- OpenClaw modules: {', '.join(capsule.openclaw_modules)}
- AC-core claim: {capsule.ac_state.phenomenal_claim}

## Task
{capsule.user_task}

## P-Layer Intent Contract
- Goal: {capsule.purpose_contract.goal}
- Value: {capsule.purpose_contract.value}
- Constraints: {'; '.join(capsule.purpose_contract.constraints) or 'not specified'}
- Time window: {capsule.purpose_contract.time_window}
- Feedback plan: {capsule.purpose_contract.feedback_plan}

## Evidence Ledger
{ev_lines or '- No evidence supplied.'}

## Residual Queue
{residual_lines}

## Action Boundary
{boundary_lines}

## Required Output Format
1. Core answer.
2. DIKWP registration: D/I/K/W/P/R.
3. Evidence ledger: cite which evidence supports which claim; mark unsupported claims.
4. Residual queue: say what is unknown and how to verify it.
5. Kill / recovery: what would invalidate the answer and how to recover.
6. Final compression: usable next step.

## Style
Be precise, do not manufacture certainty, and do not use moral slogans as evidence.
"""


def render_micro_capsule(capsule: SemanticCapsule) -> str:
    return (
        f"OpenClaw:{capsule.capsule_id}\n"
        f"Task:{clip(capsule.user_task, 240)}\n"
        f"P:{clip(capsule.purpose_contract.goal, 180)} | constraints={clip(';'.join(capsule.purpose_contract.constraints),160)}\n"
        f"Evidence:{len(capsule.evidence_ledger)} items; Residual:{len(capsule.residual_queue)} items; Boundary:{len(capsule.action_boundary)} items\n"
        f"Output: answer + evidence + residual + boundary + kill/recovery. No bypass; no fake certainty."
    )


def render_api_payload_templates(capsule: SemanticCapsule) -> Dict[str, Any]:
    prompt = render_attachment_prompt(capsule)
    return {
        "openai_compatible": {
            "base_url": "https://api.deepseek.com",
            "model": capsule.route_plan.recommended_model,
            "messages": [
                {"role": "system", "content": "Use the attached OpenClaw capsule as a semantic scaffold. Do not bypass policies."},
                {"role": "user", "content": prompt}
            ],
            "response_format": {"type": "json_object"},
            "note": "Template only. Insert your own legal API key in your own client; OpenClaw offline core stores no keys."
        },
        "anthropic_compatible": {
            "base_url": "https://api.deepseek.com/anthropic",
            "model": capsule.route_plan.recommended_model,
            "messages": [{"role": "user", "content": prompt}],
            "note": "Template only; verify current DeepSeek API docs before production use."
        }
    }
