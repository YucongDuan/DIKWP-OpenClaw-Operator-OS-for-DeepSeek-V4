"""Optional Streamlit UI.
Run: streamlit run src/dikwp_openclaw/app.py
"""
from __future__ import annotations
import json
from .capsule import build_capsule, render_attachment_prompt
from .auditor import audit_answer


def main():
    import streamlit as st  # optional dependency
    st.title("DIKWP OpenClaw OS for DeepSeek V4")
    task_text = st.text_area("Task JSON", height=260, value='{"title":"demo","user_task":"生成企业AI试点方案","evidence":[]}')
    if st.button("Build Capsule"):
        capsule = build_capsule(json.loads(task_text))
        st.json(capsule.to_dict())
        st.markdown(render_attachment_prompt(capsule))
    answer = st.text_area("Answer to audit", height=220)
    if st.button("Audit Answer") and answer:
        capsule = build_capsule(json.loads(task_text))
        st.json(audit_answer(answer, capsule).to_dict())

if __name__ == "__main__":
    main()
