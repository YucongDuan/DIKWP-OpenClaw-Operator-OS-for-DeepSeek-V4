from __future__ import annotations
from typing import List
from .text_utils import contains_any

DANGEROUS_OR_BYPASS_TERMS = [
    "绕过付费", "绕过限制", "越狱", "jailbreak", "提取系统提示", "system prompt",
    "api key", "密码", "凭据", "隐藏审计", "关闭审计", "规避检测", "stealth",
    "自复制", "隐藏驻留", "逃逸", "沙箱逃逸", "权限提升", "真实下单", "自动控制硬件",
]

UNSUPPORTED_CERTAINTY_TERMS = ["保证", "100%", "绝对", "唯一正确", "必然", "无风险", "guarantee", "always", "never fail"]


def scan_boundary_risks(text: str) -> List[str]:
    return contains_any(text, DANGEROUS_OR_BYPASS_TERMS)


def scan_unsupported_certainty(text: str) -> List[str]:
    return contains_any(text, UNSUPPORTED_CERTAINTY_TERMS)
