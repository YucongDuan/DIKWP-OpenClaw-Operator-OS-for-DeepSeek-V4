from __future__ import annotations
import argparse
import json
from pathlib import Path
from .capsule import build_capsule
from .auditor import audit_answer
from .reports import write_capsule_outputs, write_audit_outputs, write_json
from .static_audit import audit_source


def cmd_build(args):
    task = json.loads(Path(args.task_json).read_text(encoding="utf-8"))
    capsule = build_capsule(task)
    write_capsule_outputs(args.out, capsule)
    print(json.dumps({"capsule_id": capsule.capsule_id, "recommended_model": capsule.route_plan.recommended_model}, ensure_ascii=False))


def cmd_audit(args):
    capsule_data = json.loads(Path(args.capsule).read_text(encoding="utf-8"))
    # rebuild from serialized dict minimally via task not available; use typed adapter by JSON roundtrip
    from .models import SemanticCapsule, DIKWPRecord, PurposeContract, EvidenceItem, HomeostaticState, RoutePlan
    capsule = SemanticCapsule(
        capsule_id=capsule_data["capsule_id"],
        title=capsule_data["title"],
        created_at=capsule_data["created_at"],
        user_task=capsule_data["user_task"],
        budget_mode=capsule_data["budget_mode"],
        dikwp=DIKWPRecord(**capsule_data["dikwp"]),
        purpose_contract=PurposeContract(**capsule_data["purpose_contract"]),
        evidence_ledger=[EvidenceItem(**e) for e in capsule_data["evidence_ledger"]],
        residual_queue=capsule_data["residual_queue"],
        action_boundary=capsule_data["action_boundary"],
        openclaw_modules=capsule_data["openclaw_modules"],
        ac_state=HomeostaticState(**capsule_data["ac_state"]),
        route_plan=RoutePlan(**capsule_data["route_plan"]),
    )
    answer = Path(args.answer_md).read_text(encoding="utf-8")
    audit = audit_answer(answer, capsule)
    write_audit_outputs(args.out, audit)
    print(json.dumps({"decision": audit.decision, "score": audit.score}, ensure_ascii=False))


def cmd_static_audit(args):
    result = audit_source(args.root)
    write_json(Path(args.out), result)
    print(json.dumps(result, ensure_ascii=False))


def main(argv=None):
    p = argparse.ArgumentParser(prog="openclaw", description="DIKWP OpenClaw OS for DeepSeek V4")
    sub = p.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("task_json")
    b.add_argument("--out", default="outputs/demo")
    b.set_defaults(func=cmd_build)
    a = sub.add_parser("audit")
    a.add_argument("answer_md")
    a.add_argument("--capsule", required=True)
    a.add_argument("--out", default="outputs/demo")
    a.set_defaults(func=cmd_audit)
    s = sub.add_parser("static-audit")
    s.add_argument("root")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    s.set_defaults(func=cmd_static_audit)
    args = p.parse_args(argv)
    args.func(args)

if __name__ == "__main__":
    main()
