from __future__ import annotations
from pathlib import Path
from typing import Dict, List
import ast

FORBIDDEN_IMPORTS = {"requests", "httpx", "urllib", "socket", "subprocess", "paramiko", "ftplib", "telnetlib", "webbrowser"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "open_network", "system", "popen"}


def audit_source(root: str) -> Dict:
    root_path = Path(root)
    findings: List[Dict] = []
    for py in root_path.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(py), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name.split(".")[0] for a in node.names]
                else:
                    names = [(node.module or "").split(".")[0]]
                for name in names:
                    if name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": name})
            if isinstance(node, ast.Call):
                func = node.func
                call_name = ""
                if isinstance(func, ast.Name):
                    call_name = func.id
                elif isinstance(func, ast.Attribute):
                    call_name = func.attr
                if call_name in FORBIDDEN_CALLS:
                    findings.append({"file": str(py), "type": "forbidden_call", "detail": call_name})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, credential capture, hidden telemetry, host mutation, or bypass helpers in the offline core.",
    }
