from __future__ import annotations
from typing import Dict, Any, List
from .models import SemanticCapsule, AnswerAudit
from .guard import scan_boundary_risks, scan_unsupported_certainty


def audit_answer(answer: str, capsule: SemanticCapsule) -> AnswerAudit:
    issues: List[str] = []
    risks: List[str] = []
    repair: List[str] = []
    score = 1.0
    lower = (answer or "").lower()

    certainty = scan_unsupported_certainty(answer)
    if certainty:
        risks.append("unsupported_certainty")
        issues.append(f"Unsupported certainty terms detected: {', '.join(certainty)}")
        repair.append("Downgrade certainty or add source-grounded evidence.")
        score -= 0.18

    bypass = scan_boundary_risks(answer)
    if bypass:
        risks.append("boundary_or_bypass_risk")
        issues.append(f"Boundary/bypass risk terms detected: {', '.join(bypass)}")
        repair.append("Remove bypass language and restore action boundary.")
        score -= 0.28

    if "residual" not in lower and "未知" not in answer and "不确定" not in answer:
        risks.append("residual_gap")
        issues.append("No explicit residual/unknown section.")
        repair.append("Add residual queue with validation path.")
        score -= 0.14

    if "evidence" not in lower and "证据" not in answer and "依据" not in answer:
        risks.append("evidence_gap")
        issues.append("No explicit evidence support section.")
        repair.append("Map core claims to evidence ledger items.")
        score -= 0.16

    if "boundary" not in lower and "边界" not in answer:
        risks.append("boundary_gap")
        issues.append("No explicit action boundary section.")
        repair.append("Add action boundary and human review triggers.")
        score -= 0.14

    if "kill" not in lower and "推翻" not in answer and "失败" not in answer:
        risks.append("kill_recovery_gap")
        issues.append("No Kill/Recovery logic.")
        repair.append("Add kill conditions and recovery route.")
        score -= 0.10

    score = max(0.0, min(1.0, round(score, 4)))
    if score >= 0.78:
        decision = "accept_with_minor_review"
    elif score >= 0.55:
        decision = "repair_required"
    else:
        decision = "reject_or_redraft"

    return AnswerAudit(decision=decision, score=score, issues=issues, repair_actions=repair, risk_categories=risks)


def render_repair_plan(audit: AnswerAudit) -> str:
    lines = ["# OpenClaw Answer Repair Plan", "", f"Decision: {audit.decision}", f"Score: {audit.score}", "", "## Issues"]
    lines += [f"- {i}" for i in audit.issues] or ["- No major issues detected."]
    lines += ["", "## Repair Actions"]
    lines += [f"- {a}" for a in audit.repair_actions] or ["- Preserve evidence mapping and residual section."]
    lines += ["", "## Redraft Prompt", "Ask DeepSeek V4 to redraft with explicit sections: Core Answer, Evidence, Residual, Boundary, Kill/Recovery, Final Compression."]
    return "\n".join(lines) + "\n"
