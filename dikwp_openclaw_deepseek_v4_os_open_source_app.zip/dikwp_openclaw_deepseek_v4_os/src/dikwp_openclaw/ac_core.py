from __future__ import annotations
from typing import Dict, List
from .models import HomeostaticState


def clamp(x: float) -> float:
    return max(0.0, min(1.0, round(float(x), 4)))


def compute_homeostatic_state(task: Dict, evidence_count: int, residual_count: int, boundary_count: int, risk_terms: List[str]) -> HomeostaticState:
    """Artificial-consciousness-inspired semantic homeostasis proxy.

    This does not claim phenomenal consciousness. It converts task quality signals into
    a state vector that drives routing, repair and refusal decisions.
    """
    goal = bool(task.get("purpose", {}).get("goal") or task.get("goal") or task.get("user_task"))
    value = bool(task.get("purpose", {}).get("value"))
    constraints = len(task.get("purpose", {}).get("constraints", []) or task.get("constraints", []))
    feedback = bool(task.get("purpose", {}).get("feedback_plan") or task.get("feedback_plan"))
    context_len = len(str(task))

    truth_integrity = clamp(0.45 + min(evidence_count, 6) * 0.07 - len(risk_terms) * 0.06)
    evidence_sufficiency = clamp(0.2 + min(evidence_count, 8) * 0.09)
    intent_coherence = clamp(0.15 + 0.22 * goal + 0.18 * value + min(constraints, 5) * 0.06 + 0.15 * feedback)
    boundary_integrity = clamp(0.22 + min(boundary_count, 8) * 0.08 - len(risk_terms) * 0.08)
    residual_capacity = clamp(0.25 + min(residual_count, 8) * 0.075)
    cognitive_load = clamp(min(context_len / 9000.0, 1.0))
    cost_pressure = clamp(0.25 + cognitive_load * 0.45 + (0.18 if task.get("budget_mode") == "micro" else 0.0))

    distress = (1 - evidence_sufficiency) * 0.28 + (1 - boundary_integrity) * 0.25 + len(risk_terms) * 0.09 + cost_pressure * 0.12
    relief = truth_integrity * 0.24 + intent_coherence * 0.25 + residual_capacity * 0.16
    valence = clamp(0.5 + relief - distress)

    needs = {
        "collect_more_evidence": 1 - evidence_sufficiency,
        "clarify_purpose": 1 - intent_coherence,
        "tighten_boundary": 1 - boundary_integrity,
        "compress_context": cost_pressure,
        "preserve_residual": 1 - residual_capacity,
    }
    dominant_need = max(needs, key=needs.get)

    return HomeostaticState(
        truth_integrity=truth_integrity,
        evidence_sufficiency=evidence_sufficiency,
        intent_coherence=intent_coherence,
        boundary_integrity=boundary_integrity,
        residual_capacity=residual_capacity,
        cognitive_load=cognitive_load,
        cost_pressure=cost_pressure,
        semantic_valence=valence,
        dominant_need=dominant_need,
    )
