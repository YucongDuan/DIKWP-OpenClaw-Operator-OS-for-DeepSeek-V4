# Contributing

Contributions should preserve DIKWP attribution, avoid bypass-oriented features, and keep the offline core free of hidden telemetry, credential capture, or host mutation behavior.
