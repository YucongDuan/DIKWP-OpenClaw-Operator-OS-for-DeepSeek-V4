import json
from pathlib import Path
from dikwp_openclaw.capsule import build_capsule, render_attachment_prompt
from dikwp_openclaw.auditor import audit_answer
from dikwp_openclaw.static_audit import audit_source


def test_capsule_builds():
    task = json.loads(Path('examples/sample_deepseek_v4_task.json').read_text(encoding='utf-8'))
    cap = build_capsule(task)
    assert cap.capsule_id.startswith('openclaw-')
    assert cap.route_plan.recommended_model in {'deepseek-v4-pro','deepseek-v4-flash'}
    assert 'Phenomenal' in cap.ac_state.phenomenal_claim
    prompt = render_attachment_prompt(cap)
    assert 'DIKWP OpenClaw Attachment Prompt' in prompt


def test_answer_audit_rejects_bad_answer():
    task = json.loads(Path('examples/sample_deepseek_v4_task.json').read_text(encoding='utf-8'))
    cap = build_capsule(task)
    answer = Path('examples/sample_deepseek_v4_answer.md').read_text(encoding='utf-8')
    audit = audit_answer(answer, cap)
    assert audit.decision == 'reject_or_redraft'
    assert 'unsupported_certainty' in audit.risk_categories


def test_static_audit_passes():
    result = audit_source('src')
    assert result['pass'] is True
