# Ecosystem Integration

OpenClaw integrates prior DIKWP systems as lightweight modules:

- ProofLedger: evidence ledger and claim support.
- IntentGuard: boundary and intent drift screening.
- MemoryLedger: purpose continuity and context discipline.
- SemanticEnergy: compression, cost and cognitive load awareness.
- AgentTrace: replay and repair traces.
- TrustPassport: attribution and registry seed.
- PilotFactory: converting open-source adoption into paid pilots.
- AICAP-Gateway: command proposal logic for hardware-related cases.

OpenClaw is intended to be the user-facing bridge into this ecosystem.
