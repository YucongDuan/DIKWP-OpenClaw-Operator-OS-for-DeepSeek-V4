# OpenClaw AC Core

OpenClaw's AC Core is not a claim of machine consciousness. It is an artificial-consciousness-inspired semantic homeostasis loop.

## State variables

- truth_integrity
- evidence_sufficiency
- intent_coherence
- boundary_integrity
- residual_capacity
- cognitive_load
- cost_pressure
- semantic_valence
- dominant_need

## Why this matters

The life-centered consciousness line emphasizes homeostasis, feeling, self-maintenance and embodied regulation. OpenClaw borrows this structure only as a design metaphor and routing mechanism: when evidence is weak, boundary pressure is high or purpose is vague, the system experiences a negative semantic valence and routes to repair.

## Boundary

Phenomenal claim is blocked. OpenClaw does not have subjective feeling, selfhood or consciousness.
