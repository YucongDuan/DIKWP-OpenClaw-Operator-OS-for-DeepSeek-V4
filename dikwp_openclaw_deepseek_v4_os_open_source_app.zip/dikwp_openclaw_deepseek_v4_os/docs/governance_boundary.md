# Governance Boundary

OpenClaw may be used for:

- task clarification;
- semantic capsule generation;
- DeepSeek prompt structuring;
- evidence mapping;
- answer audit;
- residual preservation;
- repair prompts;
- education, enterprise planning and research.

OpenClaw must not be used for:

- jailbreaks;
- hidden prompt extraction;
- payment, quota, rate-limit or access bypass;
- credential capture;
- stealth persistence;
- audit evasion;
- automatic high-risk decisions;
- claims that OpenClaw has subjective consciousness.
