# Architecture

OpenClaw has five structural parts:

## 1. Left Claw: IntentProofCompiler

Compiles user task, evidence, P-layer intent, constraints, residuals and output requirements into a portable semantic capsule.

## 2. Right Claw: AnswerAuditRepair

Audits model output for unsupported certainty, missing evidence, missing residual, missing action boundary and missing Kill/Recovery.

## 3. Shell: BoundaryGuard

Prevents OpenClaw from becoming a bypass tool. It flags requests involving jailbreak, hidden system prompts, credentials, stealth, audit shutdown, self-replication, persistence or host escape.

## 4. Heart: AC-SemanticHomeostasis

A proxy homeostasis loop inspired by DIKWP artificial consciousness research. It tracks truth integrity, evidence sufficiency, intent coherence, boundary integrity, residual capacity, cognitive load and cost pressure. It does not claim subjective experience.

## 5. Tail: RecoveryPlan

When an answer is weak, OpenClaw generates a repair prompt and fallback capsule.
