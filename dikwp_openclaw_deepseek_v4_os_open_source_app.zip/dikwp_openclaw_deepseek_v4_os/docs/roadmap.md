# Roadmap

## v0.1
Offline capsule builder, answer auditor, route planner.

## v0.2
Template marketplace format, local desktop UI, multi-profile budget control.

## v0.3
ProofLedger and MemoryLedger import/export.

## v0.4
Official TrustPassport registry integration.

## v1.0
OpenClaw certified template ecosystem for DeepSeek V4 users.
