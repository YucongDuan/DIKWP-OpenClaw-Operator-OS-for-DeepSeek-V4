# Strategic Moat Design

OpenClaw should be open enough to spread, but not so naked that it loses DIKWP strategic value.

## Open layer

- capsule schema;
- offline CLI;
- prompt templates;
- audit heuristics;
- demo examples;
- documentation.

## Controlled official value layer

- official OpenClaw capsule registry;
- signed template packs;
- DeepSeek scenario training;
- enterprise capsule review;
- DIKWP TrustPassport badge;
- certified OpenClaw designer program;
- industry templates for law, education, health, enterprise, finance and industrial AI.

## Copycat strategy

Copycats can copy code, but should not be able to honestly copy the official registry, signed template lineage, certification program or original DIKWP attribution.
