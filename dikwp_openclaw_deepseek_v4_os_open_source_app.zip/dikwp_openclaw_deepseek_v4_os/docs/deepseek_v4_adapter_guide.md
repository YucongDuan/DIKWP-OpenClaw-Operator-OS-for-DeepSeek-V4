# DeepSeek V4 Adapter Guide

OpenClaw does not call the DeepSeek API by itself. It generates copy-paste prompts and API payload templates.

## Official compatibility assumption

DeepSeek API documentation describes OpenAI-compatible and Anthropic-compatible API formats. OpenClaw therefore generates both template styles.

## Model routing

- `deepseek-v4-flash`: low-cost, low-latency, normal tasks, draft generation.
- `deepseek-v4-pro`: high-risk, evidence-heavy, long-context, reasoning-heavy, policy/enterprise tasks.

## Thinking mode

OpenClaw marks whether a task should prefer thinking mode or non-thinking mode. Actual parameter names should be verified against current DeepSeek documentation before production use.

## Safety

Do not paste private raw data into any external model unless the relevant privacy, security and organizational policies allow it.
