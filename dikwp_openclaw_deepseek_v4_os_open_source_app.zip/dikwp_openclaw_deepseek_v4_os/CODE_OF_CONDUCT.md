# Code of Conduct

Use OpenClaw to improve semantic clarity, evidence quality and responsible AI collaboration. Do not use it for deception, unauthorized access or policy bypass.
