# Security Policy

OpenClaw's offline core stores no API keys and performs no network calls. Report issues related to credential handling, hidden telemetry, bypass prompts or unsafe defaults.
